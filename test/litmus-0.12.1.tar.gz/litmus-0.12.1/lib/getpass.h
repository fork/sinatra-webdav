
#ifndef GETPASS_H
#define GETPASS_H

char *fm_getpassword(const char *prompt);

#define PASSWORDLEN 256

#endif /* GETPASS_H */
